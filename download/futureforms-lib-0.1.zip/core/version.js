const version = "0.10";
console.log("Library Version " + version);
