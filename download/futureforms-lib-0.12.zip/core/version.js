const version = "0.12";
console.log("Library Version " + version);
