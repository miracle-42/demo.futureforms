const version = "0.14";
console.log("Library Version " + version);
