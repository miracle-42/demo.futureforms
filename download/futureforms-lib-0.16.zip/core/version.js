const version = "0.16";
console.log("Library Version " + version);
