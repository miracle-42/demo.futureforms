const version = "0.17";
console.log("Library Version " + version);
