const version = "0.18";
console.log("Library Version " + version);
