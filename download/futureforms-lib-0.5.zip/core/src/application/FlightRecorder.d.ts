export declare class FlightRecorder {
    static MESSAGES: number;
    private static messages$;
    private static debug$;
    static add(message: any): void;
    static debug(message: any): void;
    static dump(): void;
}
