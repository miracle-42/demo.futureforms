import { Form } from '../public/Form.js';
import { Class } from '../types/Class.js';
import { Form as InternalForm } from '../internal/Form.js';
import { TriggerFunction } from '../public/TriggerFunction.js';
import { EventFilter } from '../control/events/EventFilter.js';
import { KeyMap } from '../control/events/KeyMap.js';
import { DatabaseConnection } from '../public/DatabaseConnection.js';
/**
 * The starting point or boot-strap of a FutureForms application
 */
export declare class FormsModule {
    private root$;
    private showurl$;
    private static instance;
    /** Static method to return the singleton */
    static get(): FormsModule;
    /** Utility. Use with care since javascript is actually single-threaded */
    static sleep(ms: number): Promise<boolean>;
    constructor();
    /** Whether or not to display the active form in the url */
    get showurl(): boolean;
    /** Whether or not to display the active form in the url */
    set showurl(flag: boolean);
    /** The root element to which 'popup' forms will be added (default document.body) */
    getRootElement(): HTMLElement;
    /** The root element to which 'popup' forms will be added (default document.body) */
    setRootElement(root: HTMLElement): void;
    /** Make a Form navigable directly via the URL */
    setURLNavigable(name: string, nav: boolean): void;
    /** Get the latest javascript event */
    getJSEvent(): any;
    /** Map a component to string (or the name of the class) */
    mapComponent(clazz: Class<any>, path?: string): void;
    /** Get the string a given class or class-name is mapped to */
    static getFormPath(clazz: Class<any> | string): string;
    /** Get the component a given path is mapped to */
    getComponent(path: string): Class<any>;
    /** Parse a given Element to find and process FutureForms elements */
    parse(doc?: Element): void;
    /** Update the internal KeyMap based on a new KeyMap */
    updateKeyMap(map: Class<KeyMap>): void;
    /** Open the form defined in the URL */
    OpenURLForm(): boolean;
    /** Retrive the current active Form */
    getCurrentForm(): Form;
    /** Retrive the current active HTMLElement */
    getCurrentField(): HTMLElement;
    /** Emulate a user key-stroke */
    sendkey(key: KeyMap | string): Promise<boolean>;
    /** Whether a given DatabaseConnection has outstanding transactions */
    hasTransactions(connection?: DatabaseConnection): boolean;
    /** Issue commit on all DatabaseConnection's */
    commit(): Promise<boolean>;
    /** Issue rollback on all DatabaseConnection's */
    rollback(): Promise<boolean>;
    /** Popup a message */
    message(msg: string, title?: string): void;
    /** Popup a warning */
    warning(msg: string, title?: string): void;
    /** Popup a fatal */
    fatal(msg: string, title?: string): void;
    /** Get all active forms */
    getRunningForms(): Form[];
    /** Create a form based on the page */
    createform(form: Class<Form | InternalForm> | string, page: HTMLElement, parameters?: Map<any, any>): Promise<Form>;
    /** Create and attach a form to the container (or root-element) */
    showform(form: Class<Form | InternalForm> | string, parameters?: Map<any, any>, container?: HTMLElement): Promise<Form>;
    /** Show the blocking 'loading' html */
    showLoading(message: string): number;
    /** Remove the blocking 'loading' html */
    hideLoading(thread: number): void;
    /** Raise a Custom Event */
    raiseCustomEvent(source: any): Promise<boolean>;
    /** Remove an event-listener */
    removeEventListener(id: object): void;
    /** Add an event-listener */
    addEventListener(method: TriggerFunction, filter?: EventFilter | EventFilter[]): object;
    /** Add an event-listener on a given Form */
    addFormEventListener(form: Form | InternalForm, method: TriggerFunction, filter?: EventFilter | EventFilter[]): object;
}
