/**
 * Data class just holding a piece of HTML
 */
export declare class HTMLFragment {
    content: string | Element;
}
