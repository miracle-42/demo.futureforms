import { Tag } from "./Tag.js";
export declare class ImplAttribute implements Tag {
    recursive: boolean;
    private static id;
    private static MAX;
    parse(_component: any, tag: HTMLElement, attr: string): HTMLElement;
    private showform;
}
