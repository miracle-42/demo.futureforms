import { Tag } from "./Tag.js";
export declare class Include implements Tag {
    parse(_component: any, tag: HTMLElement, _attr: string): HTMLElement;
}
