/**
 * User defined custom event
 */
export interface CustomEvent {
    source: any;
    jsevent: any;
}
