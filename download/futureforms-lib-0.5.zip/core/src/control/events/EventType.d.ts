/**
    Form triggers fire in context of a form and block.
    Triggers fires first at field level, then block and form level.

    Two or more form triggers cannot run simultaneously in that context.
    E.G. you cannot delete a row while navigating in the same block.

    A few select triggers are considered safe for further action.

    Triggers that fire before anything else happens in the form I.E. onNewForm and PostViewInit.
    And PostChange, that fires after everything else when modifying a field.


    In general if a trigger returns false, execution stops. On top of this

    On-triggers prevents the event to happen.
    When-triggers marks the row/field invalid.


    Non form triggers like PreCommit is not restricted, but should be used with great care.
*/
export declare enum EventType {
    Key = 0,
    Mouse = 1,
    Custom = 2,
    WhenMenuBlur = 3,
    WhenMenuFocus = 4,
    Connect = 5,
    Disconnect = 6,
    PreCommit = 7,
    PostCommit = 8,
    PreRollback = 9,
    PostRollback = 10,
    OnLockRecord = 11,
    OnRecordLocked = 12,
    OnTransaction = 13,
    onNewForm = 14,
    OnCloseForm = 15,
    PostViewInit = 16,
    PostCloseForm = 17,
    PreForm = 18,
    PostForm = 19,
    PreBlock = 20,
    PostBlock = 21,
    PreRecord = 22,
    PostRecord = 23,
    OnRecord = 24,
    PreField = 25,
    PostField = 26,
    PostChange = 27,
    OnEdit = 28,
    WhenValidateField = 29,
    OnFetch = 30,
    PreQuery = 31,
    PostQuery = 32,
    OnCreateRecord = 33,
    PreInsert = 34,
    PostInsert = 35,
    PreUpdate = 36,
    PostUpdate = 37,
    PreDelete = 38,
    PostDelete = 39,
    WhenValidateRecord = 40
}
export declare class EventGroup {
    private types;
    static FormEvents: EventGroup;
    static ApplEvents: EventGroup;
    constructor(types: EventType[]);
    has(type: EventType): boolean;
}
