import { Form } from "../Form.js";
export declare class Alert extends Form {
    private grap;
    static WIDTH: number;
    static HEIGHT: number;
    private closeButton;
    static BlurStyle: string;
    constructor();
    private done;
    private initialize;
    focus(): Promise<boolean>;
    static page: string;
}
