import { Class } from "../../types/Class.js";
/**
 * Very simple html page that displays keymappings
 * Mostly acts as an example
 */
export declare class KeyMapPage {
    private static ul;
    static show(map?: Class<any>): HTMLElement;
    static hide(): void;
}
