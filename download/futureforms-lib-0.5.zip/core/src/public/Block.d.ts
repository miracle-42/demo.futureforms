import { Form } from './Form.js';
import { Record } from './Record.js';
import { ListOfValues } from './ListOfValues.js';
import { DateConstraint } from './DateConstraint.js';
import { KeyMap } from '../control/events/KeyMap.js';
import { FieldProperties } from './FieldProperties.js';
import { TriggerFunction } from './TriggerFunction.js';
import { FilterStructure } from '../model/FilterStructure.js';
import { DataSource } from '../model/interfaces/DataSource.js';
import { EventFilter } from '../control/events/EventFilter.js';
import { RecordState } from '../model/Record.js';
/**
 * Intersection between datasource and html elements
 *
 * All generic code for a block should be put here, ie
 * 	Lookups
 * 	Triggers
 * 	List of values
 * 	etc
 */
export declare class Block {
    private form$;
    private name$;
    private updateallowed$;
    /** Allow Query By Example */
    qbeallowed: boolean;
    /** Can block be queried */
    queryallowed: boolean;
    /** Is insert allowed */
    insertallowed: boolean;
    /** Is delete allowed */
    deleteallowed: boolean;
    /**
     * @param form : The form to attach to
     * @param name : The name of the block, used for binding elements
     */
    constructor(form: Form, name: string);
    get form(): Form;
    get name(): string;
    /** Is update allowed */
    get updateallowed(): boolean;
    /** Is update allowed */
    set updateallowed(flag: boolean);
    /** The dynamic query filters applied to this block */
    get filter(): FilterStructure;
    /** Current row number in block */
    get row(): number;
    /** Number of displayed rows in block */
    get rows(): number;
    /** Set focus on this block */
    focus(): Promise<boolean>;
    /** Current record number in block */
    get record(): number;
    /** The state of the current record */
    get state(): RecordState;
    /** Get all field names */
    get fields(): string[];
    /** Flush changes to backend */
    flush(): void;
    /** Clear the block. If force, no validation will take place */
    clear(force?: boolean): Promise<boolean>;
    /** Is the block in query mode */
    queryMode(): boolean;
    /** Is the block empty */
    empty(): boolean;
    /** Refresh (re-query) the record @param offset : offset to current record */
    refresh(offset?: number): Promise<void>;
    /** Is field bound to this block */
    hasField(name: string): boolean;
    /** Show the datepicker for the specified field */
    showDatePicker(field: string): void;
    /** Show the LOV associated with the field. Normally only 1 LOV can be active, force overrules this rule */
    showListOfValues(field: string, force?: boolean): void;
    /** Simulate keystroke @param key: the keystroke @param field: send from field @param clazz: narrow in field */
    sendkey(key: KeyMap, field?: string, clazz?: string): Promise<boolean>;
    /** Perform the query details operation */
    querydetails(field?: string): Promise<boolean>;
    /** Navigate to previous record */
    prevrecord(): Promise<boolean>;
    /** Navigate to next record */
    nextrecord(): Promise<boolean>;
    /** Navigate to row and optionally field @param row: the to navigate to*/
    goRow(row: number): Promise<boolean>;
    /** Navigate to field @param clazz: narrow in field*/
    goField(field: string, clazz?: string): Promise<boolean>;
    /** Show a message (similar to js alert) */
    message(msg: string, title?: string): void;
    /** Show a warning (similar to js alert) */
    warning(msg: string, title?: string): void;
    /** Is this a control block (not bound to a datasource) */
    isControlBlock(): boolean;
    /** Bind LOV to field(s) */
    setListOfValues(lov: ListOfValues, field: string | string[]): void;
    /** Remove LOV from field(s) */
    removeListOfValues(field: string | string[]): void;
    /** Specify a constraint on possible valid dates */
    setDateConstraint(constraint: DateConstraint, field: string | string[]): void;
    /** Get data from datasource @param header: include column names @param all: fetch all data from datasource */
    getSourceData(header?: boolean, all?: boolean): Promise<any[][]>;
    /** As getSourceData but copies the data to the clipboard. Requires https */
    saveDataToClipBoard(header?: boolean, all?: boolean): Promise<void>;
    get datasource(): DataSource;
    set datasource(source: DataSource);
    /** Delete the current record */
    delete(): Promise<boolean>;
    /** Insert a blank record @param before: Insert above the current row */
    insert(before?: boolean): Promise<boolean>;
    getValue(field: string): any;
    setValue(field: string, value: any): void;
    /** Is the block in a valid state */
    isValid(field: string): boolean;
    /** Mark the block valid */
    setValid(field: string, flag: boolean): void;
    getCurrentField(): string;
    /** Is block synchronized with backend */
    hasPendingChanges(): boolean;
    /** Show the last query for this block */
    showLastQuery(): void;
    /** setAndValidate field value as if changed by a user (fire all events) */
    setAndValidate(field: string, value: any): Promise<boolean>;
    /** Lock current record */
    lock(): Promise<void>;
    /** Mark the current record as dirty */
    setDirty(field?: string): void;
    getRecord(offset?: number): Record;
    /** Rehash the fields. Typically after dynamic insert/delete of HTML elements */
    reIndexFieldOrder(): void;
    /** Get properties used in Query By Example mode */
    getQBEProperties(field: string): FieldProperties;
    /** Get properties used in insert mode */
    getInsertProperties(field: string): FieldProperties;
    /** Get properties used in display mode */
    getDefaultProperties(field: string): FieldProperties;
    /** As in getQBEProperties, but narrow down on the field id */
    getQBEPropertiesById(field: string, id: string): FieldProperties;
    /** As in getInsertProperties, but narrow down on the field id */
    getInsertPropertiesById(field: string, id: string): FieldProperties;
    /** As in getDefaultProperties, but narrow down on the field id */
    getDefaultPropertiesById(field: string, id: string): FieldProperties;
    /** As in getQBEProperties, but narrow down on a given class */
    getQBEPropertiesByClass(field: string, clazz?: string): FieldProperties;
    /** As in getInsertProperties, but narrow down a given class */
    getInsertPropertiesByClass(field: string, clazz?: string): FieldProperties;
    /** As in getDefaultProperties, but narrow down a given class */
    getDefaultPropertiesByClass(field: string, clazz?: string): FieldProperties;
    /** Get properties for all fields in Query By Example mode */
    getAllQBEPropertiesByClass(field: string, clazz?: string): FieldProperties[];
    /** Get properties for all fields in insert mode */
    getAllInsertPropertiesByClass(field: string, clazz?: string): FieldProperties[];
    /** Get properties for all fields in display mode */
    getAllDefaultPropertiesByClass(field: string, clazz?: string): FieldProperties[];
    /** Apply Query By Example properties to field @param clazz: narrow down on class */
    setQBEProperties(props: FieldProperties, field: string, clazz?: string): void;
    /** Apply insert properties to field @param clazz: narrow down on class */
    setInsertProperties(props: FieldProperties, field: string, clazz?: string): void;
    /** Apply display properties to field @param clazz: narrow down on class */
    setDefaultProperties(props: FieldProperties, field: string, clazz?: string): void;
    /** Apply Query By Example properties to field @param clazz: narrow down on id */
    setQBEPropertiesById(props: FieldProperties, field: string, id: string): void;
    /** Apply insert properties to field @param clazz: narrow down on id */
    setInsertPropertiesById(props: FieldProperties, field: string, id: string): void;
    /** Apply display properties to field @param clazz: narrow down on id */
    setDefaultPropertiesById(props: FieldProperties, field: string, id: string): void;
    /** Re query the block with current filters */
    reQuery(): Promise<boolean>;
    /** Escape Query By Example mode */
    cancelQueryMode(): void;
    /** Enter Query By Example mode */
    enterQueryMode(): Promise<boolean>;
    /** Execute query on block */
    executeQuery(): Promise<boolean>;
    /** Remove event listener @param handle: the handle returned when applying the event listener */
    removeEventListener(handle: object): void;
    /** Apply event listener @param filter: filter on the event */
    addEventListener(method: TriggerFunction, filter?: EventFilter | EventFilter[]): object;
    /** Dump the fetched records to the console */
    dump(): void;
}
