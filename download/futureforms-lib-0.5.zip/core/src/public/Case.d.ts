/**
 * Types of upper/lower casing of strings
 */
export declare enum Case {
    mixed = 0,
    lower = 1,
    upper = 2,
    initcap = 3
}
