/**
 * Basic HTTP connection to backend.
 * This class is meant for extending and does not implement any username/password security.
 */
export declare class Connection {
    private base$;
    private usr$;
    private pwd$;
    private headers$;
    private method$;
    private success$;
    /** Create connection. If no url specified, the Origin of the page is used */
    constructor(url?: string | URL);
    /** The base url for this connection */
    get baseURL(): URL;
    /** Not used in base class */
    get username(): string;
    /** Not used in base class */
    set username(username: string);
    /** Not used in base class */
    get password(): string;
    /** Not used in base class */
    set password(password: string);
    /** Whether the last request was successfull */
    get success(): boolean;
    /** Get the request headers */
    get headers(): any;
    /** Set the request headers */
    set headers(headers: any);
    /** Set the base url */
    set baseURL(url: string | URL);
    /** Not used in base class */
    get transactional(): boolean;
    /** Perform HTTP GET */
    get(url?: string | URL, raw?: boolean): Promise<any>;
    /** Perform HTTP POST */
    post(url?: string | URL, payload?: string | any, raw?: boolean): Promise<any>;
    /** Perform HTTP PATCH */
    patch(url?: string | URL, payload?: string | any, raw?: boolean): Promise<any>;
    private invoke;
}
