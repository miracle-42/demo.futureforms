import { ConnectionScope } from "../database/ConnectionScope.js";
/**
 * Connection to DatabaseJS.
 */
export declare class DatabaseConnection {
    private conn$;
    /** Transaction timeout in seconds, only with scope=transactional */
    static get TRXTIMEOUT(): number;
    /** Transaction timeout in seconds, only with scope=transactional */
    static set TRXTIMEOUT(timeout: number);
    /** Connection timeout in seconds, only with scope=transactional */
    static get CONNTIMEOUT(): number;
    /** Connection timeout in seconds, only with scope=transactional */
    static set CONNTIMEOUT(timeout: number);
    /** See connection */
    constructor(url?: string | URL);
    /** Number of row locks */
    get locks(): number;
    /** The connection scope */
    get scope(): ConnectionScope;
    /** The connection scope */
    set scope(scope: ConnectionScope);
    /** Is connection scope transactional */
    get transactional(): boolean;
    /** Set secret for non database connections */
    set preAuthenticated(secret: string);
    /** Connect to database */
    connect(username?: string, password?: string): Promise<boolean>;
    /** Disconnect from database */
    disconnect(): Promise<boolean>;
    /** Is connected to database */
    connected(): boolean;
    /** Commit all transactions */
    commit(): Promise<boolean>;
    /** Rollback all transactions */
    rollback(): Promise<boolean>;
}
