import { TriggerFunction } from './TriggerFunction.js';
import { EventFilter } from '../control/events/EventFilter.js';
/**
 * Implements addEventListener. Meant for extending custom classes that needs event listeners
 */
export declare class EventListener {
    /** Remove an eventlistener. This should also be done before setView is called */
    removeEventListener(handle: object): void;
    /** Add an eventlistener */
    addEventListener(method: TriggerFunction, filter?: EventFilter | EventFilter[]): object;
}
