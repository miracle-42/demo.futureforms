import { Class } from '../types/Class.js';
import { ListOfValues } from './ListOfValues.js';
import { DataType } from '../view/fields/DataType.js';
import { DataMapper } from '../view/fields/DataMapper.js';
import { BasicProperties } from '../view/fields/BasicProperties.js';
import { Formatter, SimpleFormatter } from '../view/fields/interfaces/Formatter.js';
/**
 * HTML Properties used by bound fields
 */
export declare class FieldProperties extends BasicProperties {
    constructor(properties: BasicProperties);
    /** Clone the properties */
    clone(): FieldProperties;
    /** The tag ie. div, span, input etc */
    setTag(tag: string): FieldProperties;
    /** Underlying datatype. Inherited but cannot be changed */
    setType(_type: DataType): FieldProperties;
    /** Set enabled flag */
    setEnabled(flag: boolean): FieldProperties;
    /** Set readonly flag */
    setReadOnly(flag: boolean): FieldProperties;
    /** Determines if field is bound to datasource or not. Inherited but cannot be changed */
    setDerived(_flag: boolean): FieldProperties;
    /** Set required flag */
    setRequired(flag: boolean): FieldProperties;
    /** Set hidden flag */
    setHidden(flag: boolean): FieldProperties;
    /** Set a style */
    setStyle(style: string, value: string): FieldProperties;
    /** Set all styles */
    setStyles(styles: string): FieldProperties;
    /** Remove a style */
    removeStyle(style: string): FieldProperties;
    /** Set a class */
    setClass(clazz: string): FieldProperties;
    /** Set all classes */
    setClasses(classes: string | string[]): FieldProperties;
    /** Remove a class */
    removeClass(clazz: any): FieldProperties;
    /** Set an attribute */
    setAttribute(attr: string, value?: any): FieldProperties;
    /** Set all attributes */
    setAttributes(attrs: Map<string, string>): FieldProperties;
    /** Remove an attribute */
    removeAttribute(attr: string): FieldProperties;
    /** Set the value attribute */
    setValue(value: string): FieldProperties;
    /** Set a list of valid values */
    setValidValues(values: string[] | Set<any> | Map<any, any>): FieldProperties;
    /** Set a two-way data mapper */
    setMapper(mapper: Class<DataMapper> | DataMapper | string): FieldProperties;
    /** Set formatter */
    setFormatter(formatter: Class<Formatter> | Formatter | string): FieldProperties;
    /** Set simple formatter */
    setSimpleFormatter(formatter: Class<SimpleFormatter> | SimpleFormatter | string): FieldProperties;
    /** Set listofvalues */
    setListOfValues(listofvalues: Class<ListOfValues> | ListOfValues | string): FieldProperties;
}
