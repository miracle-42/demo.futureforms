export declare enum DataType {
    date = 0,
    string = 1,
    boolean = 2,
    integer = 3,
    decimal = 4,
    datetime = 5
}
