import { Radio } from "./Radio.js";
export declare class CheckBox extends Radio {
}
