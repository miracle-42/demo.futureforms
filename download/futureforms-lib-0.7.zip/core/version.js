const version = "0.7";
console.log("Library Version " + version);
