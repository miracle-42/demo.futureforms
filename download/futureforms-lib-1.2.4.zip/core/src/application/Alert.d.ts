export declare class Alert {
    static fatal(msg: string, title: string): Promise<void>;
    static warning(msg: string, title: string): Promise<void>;
    static message(msg: string, title: string): Promise<void>;
    static callform(msg: string, title: string, warning: boolean, fatal: boolean): Promise<void>;
}
