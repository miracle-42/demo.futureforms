import { Class } from '../types/Class.js';
import { Block } from "../public/Block.js";
export declare const Column: (url: string) => (comp: Class<Block>) => void;
