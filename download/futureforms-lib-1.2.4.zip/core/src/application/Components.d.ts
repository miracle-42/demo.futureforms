import { Class } from '../types/Class.js';
export declare class Components {
    static classurl: Map<string, string>;
    static classmap: Map<string, Class<any>>;
}
