export declare class HTMLFragment {
    content: string | Element;
}
