import { Class } from '../types/Class.js';
import { Canvas as CanvasType } from './interfaces/Canvas.js';
import { ComponentFactory } from './interfaces/ComponentFactory.js';
import { Tag } from './tags/Tag.js';
export declare enum ScrollDirection {
    Up = 0,
    Down = 1
}
export interface ClassNames {
    Invalid: string;
    RowIndicator: string;
    FilterIndicator: string;
}
export declare class Properties {
    static baseurl: string;
    static ParseTags: boolean;
    static ParseEvents: boolean;
    static BindAttr: string;
    static RecordModeAttr: string;
    static RootTag: string;
    static IncludeTag: string;
    static ForeachTag: string;
    static DateDelimitors: string;
    static TimeFormat: string;
    static DateFormat: string;
    static AttributePrefix: string;
    static RequireAttributePrefix: boolean;
    static IndicatorType: string;
    static FilterIndicatorType: string;
    static Classes: ClassNames;
    static CanvasImplementationClass: Class<CanvasType>;
    static FactoryImplementation: ComponentFactory;
    static MouseScrollDirection: ScrollDirection;
    static TagLibrary: Map<string, Class<Tag>>;
    static FieldTypeLibrary: Map<string, Class<Tag>>;
    static AttributeLibrary: Map<string, Class<Tag>>;
}
