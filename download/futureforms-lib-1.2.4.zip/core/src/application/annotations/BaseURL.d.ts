import { Class } from '../../types/Class.js';
import { FormsModule } from '../FormsModule.js';
export declare const BaseURL: (url: string) => (_comp_: Class<FormsModule>) => void;
