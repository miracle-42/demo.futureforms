import { Class } from '../../types/Class.js';
import { FormsModule } from '../FormsModule.js';
export interface Component {
    path: string;
    class: Class<any>;
}
export declare const FormsPathMapping: (components: (Class<any> | Component)[]) => (_comp_: Class<FormsModule>) => void;
