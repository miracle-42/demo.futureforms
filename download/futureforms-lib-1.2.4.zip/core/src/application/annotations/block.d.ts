import { Form } from '../../public/Form.js';
export declare const block: (block: string) => (form: Form, attr: string) => void;
