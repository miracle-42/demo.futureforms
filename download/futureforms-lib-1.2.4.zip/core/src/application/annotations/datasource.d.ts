import { Form } from '../../public/Form.js';
import { Class } from '../../types/Class.js';
import { Block } from '../../public/Block.js';
import { DataSource } from '../../model/interfaces/DataSource.js';
export declare const datasource: (block: Block | string, source: Class<DataSource> | DataSource) => (form: Class<Form>) => void;
