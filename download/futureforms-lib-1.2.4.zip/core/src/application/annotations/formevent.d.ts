import { EventFilter } from '../../control/events/EventFilter.js';
export declare const formevent: (filter: EventFilter | EventFilter[]) => (lsnr: any, method: string) => any;
