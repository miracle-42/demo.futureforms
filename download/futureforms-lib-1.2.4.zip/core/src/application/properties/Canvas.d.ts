export declare class Canvas {
    static page: string;
    static ModalStyle: string;
    static CanvasStyle: string;
    static ContentStyle: string;
    static ModalClasses: string;
    static CanvasClasses: string;
    static ContentClasses: string;
    static CanvasHandleClass: string;
}
