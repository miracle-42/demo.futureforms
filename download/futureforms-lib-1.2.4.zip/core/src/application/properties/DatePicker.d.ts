export declare class DatePicker {
    static datePickerStyle: string;
    static datePickerDateStyle: string;
    static datePickerMonthStyle: string;
    static datePickerMthTextStyle: string;
    static datePickerArrowStyle: string;
    static datePickerWeekStyle: string;
    static datePickerDayStyle: string;
    static datePickerSelectedDay: string;
    static datePickerSelectedDate: string;
    static styleDatePicker(view: HTMLElement): void;
}
