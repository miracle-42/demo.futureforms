export declare class Internals {
    static header: string;
    static footer: string;
    static PopupHeaderStyle: string;
    static PopupStyle: string;
    static PopupStyleDiv: string;
    static PopupStyleLabel: string;
    static PopupStyleLogin: string;
    static PopupStyleButtonArea: string;
    static PopupStyleLowerRight: string;
    static PopupFooterStyle: any;
    static PopupCloseButton: string;
    static LoaderStyle: string;
    static stylePopupWindow(view: HTMLElement, title?: string, height?: number, width?: number): void;
}
