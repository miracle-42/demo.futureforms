import { Tag } from "./Tag.js";
export declare class Foreach implements Tag {
    parse(_component: any, tag: HTMLElement, attr: string): HTMLElement[];
}
