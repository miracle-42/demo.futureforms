import { Tag } from "./Tag.js";
export declare class FromAttribute implements Tag {
    parse(component: any, tag: HTMLElement, attr: string): string | HTMLElement | HTMLElement[];
}
