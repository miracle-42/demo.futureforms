import { Tag } from "./Tag.js";
export declare class Root implements Tag {
    parse(_component: any, tag: HTMLElement, _attr: string): HTMLElement;
}
