export interface Tag {
    parse(component: any, tag: HTMLElement, attr: string): HTMLElement | HTMLElement[] | string | null;
}
