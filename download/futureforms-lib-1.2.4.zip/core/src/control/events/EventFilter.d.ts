import { KeyMap } from "./KeyMap.js";
import { MouseMap } from "./MouseMap.js";
import { EventType } from "./EventType.js";
export interface EventFilter {
    type?: EventType;
    key?: KeyMap;
    field?: string;
    block?: string;
    mouse?: MouseMap;
}
