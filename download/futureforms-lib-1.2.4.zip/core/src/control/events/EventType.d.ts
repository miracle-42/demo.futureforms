export declare enum EventType {
    Key = 0,
    Mouse = 1,
    PreCommit = 2,
    PostCommit = 3,
    PreRollback = 4,
    PostRollback = 5,
    OnTransaction = 6,
    Connect = 7,
    Disconnect = 8,
    onNewForm = 9,
    OnCloseForm = 10,
    PostViewInit = 11,
    PostFormFocus = 12,
    PostCloseForm = 13,
    PreForm = 14,
    PostForm = 15,
    PreBlock = 16,
    PostBlock = 17,
    PreRecord = 18,
    PostRecord = 19,
    OnRecord = 20,
    OnNewRecord = 21,
    PreField = 22,
    PostField = 23,
    OnEdit = 24,
    WhenValidateField = 25,
    OnFetch = 26,
    PreQuery = 27,
    PostQuery = 28,
    PreInsert = 29,
    PostInsert = 30,
    PreUpdate = 31,
    PostUpdate = 32,
    PreDelete = 33,
    PostDelete = 34,
    OnLockRecord = 35,
    OnRecordLocked = 36,
    WhenValidateRecord = 37
}
export declare class EventGroup {
    private types;
    static FormEvents: EventGroup;
    static ApplEvents: EventGroup;
    constructor(types: EventType[]);
    has(type: EventType): boolean;
}
