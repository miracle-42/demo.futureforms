/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/*
    OBS !!
    Pre- On- and When- cannot start new transaction in same block
*/
export var EventType;
(function (EventType) {
    EventType[EventType["Key"] = 0] = "Key";
    EventType[EventType["Mouse"] = 1] = "Mouse";
    EventType[EventType["PreCommit"] = 2] = "PreCommit";
    EventType[EventType["PostCommit"] = 3] = "PostCommit";
    EventType[EventType["PreRollback"] = 4] = "PreRollback";
    EventType[EventType["PostRollback"] = 5] = "PostRollback";
    EventType[EventType["OnTransaction"] = 6] = "OnTransaction";
    EventType[EventType["Connect"] = 7] = "Connect";
    EventType[EventType["Disconnect"] = 8] = "Disconnect";
    EventType[EventType["onNewForm"] = 9] = "onNewForm";
    EventType[EventType["OnCloseForm"] = 10] = "OnCloseForm";
    EventType[EventType["PostViewInit"] = 11] = "PostViewInit";
    EventType[EventType["PostFormFocus"] = 12] = "PostFormFocus";
    EventType[EventType["PostCloseForm"] = 13] = "PostCloseForm";
    EventType[EventType["PreForm"] = 14] = "PreForm";
    EventType[EventType["PostForm"] = 15] = "PostForm";
    EventType[EventType["PreBlock"] = 16] = "PreBlock";
    EventType[EventType["PostBlock"] = 17] = "PostBlock";
    EventType[EventType["PreRecord"] = 18] = "PreRecord";
    EventType[EventType["PostRecord"] = 19] = "PostRecord";
    EventType[EventType["OnRecord"] = 20] = "OnRecord";
    EventType[EventType["OnNewRecord"] = 21] = "OnNewRecord";
    EventType[EventType["PreField"] = 22] = "PreField";
    EventType[EventType["PostField"] = 23] = "PostField";
    EventType[EventType["OnEdit"] = 24] = "OnEdit";
    EventType[EventType["WhenValidateField"] = 25] = "WhenValidateField";
    EventType[EventType["OnFetch"] = 26] = "OnFetch";
    EventType[EventType["PreQuery"] = 27] = "PreQuery";
    EventType[EventType["PostQuery"] = 28] = "PostQuery";
    EventType[EventType["PreInsert"] = 29] = "PreInsert";
    EventType[EventType["PostInsert"] = 30] = "PostInsert";
    EventType[EventType["PreUpdate"] = 31] = "PreUpdate";
    EventType[EventType["PostUpdate"] = 32] = "PostUpdate";
    EventType[EventType["PreDelete"] = 33] = "PreDelete";
    EventType[EventType["PostDelete"] = 34] = "PostDelete";
    EventType[EventType["OnLockRecord"] = 35] = "OnLockRecord";
    EventType[EventType["OnRecordLocked"] = 36] = "OnRecordLocked";
    EventType[EventType["WhenValidateRecord"] = 37] = "WhenValidateRecord";
})(EventType || (EventType = {}));
export class EventGroup {
    types;
    static FormEvents = new EventGroup([
        EventType.PreForm,
        EventType.PostForm,
        EventType.PostViewInit,
        EventType.PostFormFocus,
        EventType.PostCloseForm,
    ]);
    static ApplEvents = new EventGroup([
        EventType.Connect,
        EventType.Disconnect,
        EventType.PreCommit,
        EventType.PostCommit,
        EventType.PreRollback,
        EventType.PostRollback,
        EventType.OnTransaction,
    ]);
    constructor(types) {
        this.types = types;
    }
    has(type) {
        return (this.types.includes(type));
    }
}
