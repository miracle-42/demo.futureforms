import { MenuEntry } from "./MenuEntry.js";
export interface Menu {
    getRoot(): Promise<MenuEntry>;
    getEntries(path: string): Promise<MenuEntry[]>;
    execute(path: string): Promise<boolean>;
}
