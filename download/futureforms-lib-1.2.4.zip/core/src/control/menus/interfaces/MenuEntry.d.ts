export interface MenuEntry {
    id: any;
    display: string;
    command?: string;
    hinttext?: string;
    disabled?: boolean;
}
