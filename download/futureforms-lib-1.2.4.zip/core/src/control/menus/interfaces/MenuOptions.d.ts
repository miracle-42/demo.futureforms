export interface MenuOptions {
    skiproot?: boolean;
    singlepath?: boolean;
    openOnHoover?: boolean;
    classes?: {
        open?: string;
        common?: string;
        menuitem?: string;
        linkitem?: string;
        hinttext?: string;
        container?: string;
    };
}
