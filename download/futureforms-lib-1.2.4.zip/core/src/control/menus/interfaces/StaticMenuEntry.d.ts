import { MenuEntry } from "./MenuEntry.js";
export interface StaticMenuEntry extends MenuEntry {
    entries?: StaticMenuEntry[];
}
