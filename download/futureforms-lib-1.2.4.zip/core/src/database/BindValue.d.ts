import { DataType } from "./DataType.js";
export declare class BindValue {
    private value$;
    private name$;
    private type$;
    private out$;
    private column$;
    private force$;
    constructor(name: string, value: any, type?: DataType | string);
    get name(): string;
    set name(name: string);
    get column(): string;
    set column(column: string);
    get outtype(): boolean;
    set outtype(flag: boolean);
    get type(): string;
    set type(type: DataType | string);
    get forceDataType(): boolean;
    set forceDataType(flag: boolean);
    get value(): any;
    set value(value: any);
    toString(): string;
}
