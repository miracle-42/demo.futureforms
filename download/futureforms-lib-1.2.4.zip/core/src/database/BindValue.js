/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
import { DataType } from "./DataType.js";
export class BindValue {
    value$ = null;
    name$ = null;
    type$ = null;
    out$ = false;
    column$ = null;
    force$ = false;
    constructor(name, value, type) {
        if (typeof type != "string")
            type = DataType[type];
        this.name = name;
        this.type = type;
        this.value = value;
        this.column = name;
    }
    get name() {
        return (this.name$);
    }
    set name(name) {
        this.name$ = name;
    }
    get column() {
        return (this.column$);
    }
    set column(column) {
        this.column$ = column;
    }
    get outtype() {
        return (this.out$);
    }
    set outtype(flag) {
        this.out$ = flag;
    }
    get type() {
        if (this.type$ == null)
            return ("string");
        return (this.type$);
    }
    set type(type) {
        if (typeof type != "string")
            type = DataType[type];
        this.type$ = type;
    }
    get forceDataType() {
        return (this.force$);
    }
    set forceDataType(flag) {
        this.force$ = flag;
    }
    get value() {
        return (this.value$);
    }
    set value(value) {
        this.value$ = value;
        if (this.type$ == null && typeof value === "number")
            this.type$ = "number";
        if (value instanceof Date)
            if (this.type$ == null)
                this.type$ = "date";
        if (this.type$ == null)
            this.type$ = "string";
    }
    toString() {
        return ("{" + this.name + " " + this.type + " " + this.value + "}");
    }
}
