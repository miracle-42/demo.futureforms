import { Cursor } from "./Cursor.js";
import { SQLRest } from "./SQLRest.js";
import { ConnectionScope } from "./ConnectionScope.js";
import { Connection as BaseConnection } from "../public/Connection.js";
export declare class Connection extends BaseConnection {
    private trx$;
    private conn$;
    private touched$;
    private modified$;
    private secret$;
    private keepalive$;
    private tmowarn$;
    private scope$;
    static TRXTIMEOUT: number;
    static CONNTIMEOUT: number;
    private static conns$;
    static getAllConnections(): Connection[];
    constructor(url?: string | URL);
    get scope(): ConnectionScope;
    set scope(scope: ConnectionScope);
    set preAuthenticated(secret: string);
    connected(): boolean;
    hasTransactions(): boolean;
    connect(username?: string, password?: string): Promise<boolean>;
    disconnect(): Promise<boolean>;
    commit(): Promise<boolean>;
    rollback(): Promise<boolean>;
    select(sql: SQLRest, cursor: Cursor, rows: number, describe?: boolean): Promise<Response>;
    fetch(cursor: Cursor): Promise<Response>;
    close(cursor: Cursor): Promise<Response>;
    lock(sql: SQLRest): Promise<Response>;
    refresh(sql: SQLRest): Promise<Response>;
    insert(sql: SQLRest): Promise<Response>;
    update(sql: SQLRest): Promise<Response>;
    delete(sql: SQLRest): Promise<Response>;
    call(patch: boolean, sql: SQLRest): Promise<Response>;
    execute(patch: boolean, sql: SQLRest): Promise<Response>;
    private keepalive;
    private convert;
    sleep(ms: number): Promise<void>;
}
export declare class Response {
    rows: any[];
    message: string;
    success: boolean;
}
