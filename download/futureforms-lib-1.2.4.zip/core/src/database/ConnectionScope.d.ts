export declare enum ConnectionScope {
    stateless = 0,
    dedicated = 1,
    transactional = 2
}
