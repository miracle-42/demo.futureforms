export declare class DatabaseResponse {
    private response$;
    private columns$;
    private converted$;
    constructor(response: any, columns?: string[]);
    get failed(): boolean;
    getValue(column: string): any;
}
