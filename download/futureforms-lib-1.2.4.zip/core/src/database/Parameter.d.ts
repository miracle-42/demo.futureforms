import { DataType } from "./DataType.js";
export declare enum ParameterType {
    in = 0,
    out = 1,
    inout = 2
}
export declare class Parameter {
    value: any;
    name: string;
    dtype: string;
    ptype: ParameterType;
    constructor(name: string, value: any, dtype?: DataType | string, ptype?: ParameterType);
}
