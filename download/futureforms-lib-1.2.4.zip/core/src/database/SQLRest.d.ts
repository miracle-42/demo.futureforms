import { BindValue } from "./BindValue";
export declare class SQLRest {
    stmt: string;
    returnclause: boolean;
    bindvalues: BindValue[];
    toString(): string;
}
