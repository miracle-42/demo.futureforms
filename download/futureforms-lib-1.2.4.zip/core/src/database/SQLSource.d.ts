import { SQLRest } from "./SQLRest.js";
import { FilterStructure } from "../model/FilterStructure.js";
export declare abstract class SQLSource {
    abstract getSubQuery(filter: FilterStructure, mstcols: string | string[], detcols: string | string[]): Promise<SQLRest>;
}
