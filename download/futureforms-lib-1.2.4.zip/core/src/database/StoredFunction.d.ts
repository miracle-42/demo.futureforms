import { DataType } from "./DataType.js";
import { StoredProcedure } from "./StoredProcedure.js";
import { DatabaseConnection } from "../public/DatabaseConnection.js";
export declare class StoredFunction extends StoredProcedure {
    constructor(connection: DatabaseConnection);
    getReturnValue(): any;
    setReturnType(datatype?: DataType | string): void;
}
