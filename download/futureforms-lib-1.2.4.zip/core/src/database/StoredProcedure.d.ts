import { DataType } from "./DataType.js";
import { ParameterType } from "./Parameter.js";
import { DatabaseConnection } from "../public/DatabaseConnection.js";
export declare class StoredProcedure {
    private name$;
    private response$;
    private patch$;
    private message$;
    private conn$;
    private params$;
    private values$;
    private datetypes$;
    protected retparm$: string;
    protected returntype$: DataType | string;
    constructor(connection: DatabaseConnection);
    set patch(flag: boolean);
    error(): string;
    setName(name: string): void;
    addParameter(name: string, value: any, datatype?: DataType | string, paramtype?: ParameterType): void;
    getOutParameter(name: string): any;
    getOutParameterNames(): string[];
    execute(): Promise<boolean>;
}
