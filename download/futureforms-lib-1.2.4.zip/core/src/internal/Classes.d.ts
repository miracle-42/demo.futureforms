import { Form } from './Form.js';
import { Class } from '../types/Class.js';
export declare class Classes {
    private static zindex$;
    static AlertClass: Class<Form>;
    static DatePickerClass: Class<Form>;
    static QueryEditorClass: Class<Form>;
    static ListOfValuesClass: Class<Form>;
    static get zindex(): number;
    static isInternal(clazz: Class<Form>): boolean;
}
