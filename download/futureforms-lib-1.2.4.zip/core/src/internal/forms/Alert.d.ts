import { Form } from "../Form.js";
export declare class Alert extends Form {
    static WIDTH: number;
    static HEIGHT: number;
    private closeButton;
    private static zindex$;
    static BlurStyle: string;
    constructor();
    private done;
    private initialize;
    focus(): Promise<boolean>;
    static page: string;
}
