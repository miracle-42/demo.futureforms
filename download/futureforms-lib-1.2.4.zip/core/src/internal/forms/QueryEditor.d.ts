import { Form } from "../Form.js";
export declare class QueryEditor extends Form {
    private type;
    private values;
    private options;
    private fltprops;
    private inclprops;
    constructor();
    private skip;
    private done;
    private setOptions;
    private setType;
    private navigate;
    private initialize;
    private insert;
    private showSingle;
    private showRange;
    private showMulti;
    private hideAll;
    static page: string;
}
