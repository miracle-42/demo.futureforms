import { Form } from "../Form.js";
export declare class UsernamePassword extends Form {
    title: string;
    username: string;
    password: string;
    accepted: boolean;
    constructor();
    cancel(): Promise<boolean>;
    private accept;
    private initialize;
    static page: string;
}
