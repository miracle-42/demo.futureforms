export interface DateToken {
    pos: number;
    length: number;
    mask: string;
    value: string;
    type: DatePart;
}
export interface FormatToken {
    pos: number;
    length: number;
    mask: string;
    type: DatePart;
    delimitor: string;
}
export declare enum DatePart {
    Date = 0,
    Year = 1,
    Month = 2,
    Day = 3,
    Hour = 4,
    Minute = 5,
    Second = 6
}
export declare enum WeekDays {
    Sun = 0,
    Mon = 1,
    Tue = 2,
    Wed = 3,
    Thu = 4,
    Fri = 5,
    Sat = 6
}
export declare class dates {
    static validate(): boolean;
    static parse(datestr: string, format?: string, withtime?: boolean): Date;
    static getDays(start: WeekDays): Array<String>;
    static format(date: Date, format?: string): string;
    static tokenizeDate(date: Date, format?: string): DateToken[];
    static getTokenType(token: string): DatePart;
    static tokenizeFormat(format?: string): FormatToken[];
}
