import { Record } from "../Record.js";
import { Filter } from "../interfaces/Filter.js";
import { DataType } from "../../database/DataType.js";
import { BindValue } from "../../database/BindValue.js";
export declare class CustomFilter implements Filter {
    private column$;
    private bindval$;
    private datatype$;
    private constraint$;
    private bindvalues$;
    constructor(column: string);
    clear(): void;
    clone(): CustomFilter;
    getDataType(): string;
    setDataType(type: DataType | string): CustomFilter;
    getBindValueName(): string;
    setBindValueName(name: string): CustomFilter;
    setConstraint(values: any | any[]): CustomFilter;
    get constraint(): any | any[];
    set constraint(values: any | any[]);
    getBindValue(): BindValue;
    setBindValues(values: BindValue[]): void;
    getBindValues(): BindValue[];
    evaluate(record: Record): Promise<boolean>;
    asSQL(): string;
    toString(): string;
}
