import { Between } from "./Between.js";
export declare class DateInterval extends Between {
    constructor(column: string);
    Day(date?: Date): DateInterval;
    Week(date?: Date, start?: number): DateInterval;
    Month(date?: Date): DateInterval;
    Year(date?: Date): DateInterval;
}
