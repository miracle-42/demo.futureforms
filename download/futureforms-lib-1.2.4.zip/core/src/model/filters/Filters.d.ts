import { Like } from "./Like.js";
import { ILike } from "./ILike.js";
import { AnyOf } from "./AnyOf.js";
import { Equals } from "./Equals.js";
import { NoneOf } from "./NoneOf.js";
import { Between } from "./Between.js";
import { LessThan } from "./LessThan.js";
import { Contains } from "./Contains.js";
import { SubQuery } from "./SubQuery.js";
import { NullFilter } from "./NullFilter.js";
import { GreaterThan } from "./GreaterThan.js";
import { DateInterval } from "./DateInterval.js";
export declare class Filters {
    static Like(column: string): Like;
    static AnyOf(column: string): AnyOf;
    static ILike(column: string): ILike;
    static Equals(column: string): Equals;
    static NoneOf(column: string): NoneOf;
    static Null(column: string): NullFilter;
    static Contains(columns: string | string[]): Contains;
    static SubQuery(columns: string | string[]): SubQuery;
    static DateInterval(column: string): DateInterval;
    static LT(column: string, incl?: boolean): LessThan;
    static Between(column: string, incl?: boolean): Between;
    static GT(column: string, incl?: boolean): GreaterThan;
}
