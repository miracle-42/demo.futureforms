import { Record } from "../Record.js";
import { Filter } from "../interfaces/Filter.js";
import { DataType } from "../../database/DataType.js";
import { BindValue } from "../../database/BindValue.js";
export declare class NullFilter implements Filter {
    private column$;
    private bindval$;
    private datatype$;
    private constraint$;
    constructor(column: string);
    clear(): void;
    clone(): NullFilter;
    getDataType(): string;
    setDataType(type: DataType | string): NullFilter;
    getBindValueName(): string;
    setBindValueName(name: string): NullFilter;
    setConstraint(value: any): NullFilter;
    get constraint(): any | any[];
    set constraint(value: any | any[]);
    getBindValue(): BindValue;
    getBindValues(): BindValue[];
    evaluate(record: Record): Promise<boolean>;
    asSQL(): string;
}
