import { Record } from "../Record.js";
import { DataType } from "../../database/DataType.js";
import { BindValue } from "../../database/BindValue.js";
export interface Filter {
    clear(): void;
    asSQL(): string;
    clone(): Filter;
    constraint: any | any[];
    getBindValue(): BindValue;
    getBindValues(): BindValue[];
    getBindValueName(): string;
    setBindValueName(name: string): Filter;
    getDataType(): string;
    setDataType(type: DataType): Filter;
    setConstraint(value: any | any[]): Filter;
    evaluate(record: Record): Promise<boolean>;
}
