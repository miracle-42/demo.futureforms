import { Block } from "../Block.js";
export declare class Key {
    private name$;
    private block$;
    private fields$;
    constructor(block: string | Block, fields: string | string[]);
    get name(): string;
    get block(): string;
    get fields(): string[];
}
