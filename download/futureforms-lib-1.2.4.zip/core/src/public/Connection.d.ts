export declare class Connection {
    private base$;
    private usr$;
    private pwd$;
    private headers$;
    private method$;
    private success$;
    constructor(url?: string | URL);
    get baseURL(): URL;
    get username(): string;
    set username(username: string);
    get password(): string;
    set password(password: string);
    get success(): boolean;
    get headers(): any;
    set headers(headers: any);
    set baseURL(url: string | URL);
    get(url?: string | URL, raw?: boolean): Promise<any>;
    post(url?: string | URL, payload?: string | any, raw?: boolean): Promise<any>;
    patch(url?: string | URL, payload?: string | any, raw?: boolean): Promise<any>;
    private invoke;
}
