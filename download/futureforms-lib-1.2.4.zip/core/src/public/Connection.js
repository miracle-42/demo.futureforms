/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
import { FlightRecorder } from "../application/FlightRecorder.js";
export class Connection {
    base$ = null;
    usr$ = null;
    pwd$ = null;
    headers$ = {};
    method$ = null;
    success$ = true;
    constructor(url) {
        if (url == null)
            url = window.location.origin;
        if (typeof url === "string")
            url = new URL(url);
        this.base$ = url;
    }
    get baseURL() {
        return (this.base$);
    }
    get username() {
        return (this.usr$);
    }
    set username(username) {
        this.usr$ = username;
    }
    get password() {
        return (this.pwd$);
    }
    set password(password) {
        this.pwd$ = password;
    }
    get success() {
        return (this.success$);
    }
    get headers() {
        return (this.headers$);
    }
    set headers(headers) {
        this.headers$ = headers;
    }
    set baseURL(url) {
        if (typeof url === "string")
            url = new URL(url);
        this.base$ = url;
    }
    async get(url, raw) {
        this.method$ = "GET";
        return (this.invoke(url, null, raw));
    }
    async post(url, payload, raw) {
        this.method$ = "POST";
        return (this.invoke(url, payload, raw));
    }
    async patch(url, payload, raw) {
        this.method$ = "PATCH";
        return (this.invoke(url, payload, raw));
    }
    async invoke(url, payload, raw) {
        let body = null;
        this.success$ = true;
        let endpoint = new URL(this.base$);
        if (url)
            endpoint = new URL(url, endpoint);
        if (payload) {
            if (typeof payload != "string")
                payload = JSON.stringify(payload);
        }
        if (!endpoint.toString().endsWith("ping"))
            FlightRecorder.add("@connection: " + endpoint + (payload ? " " + JSON.stringify(payload) : ""));
        let http = await fetch(endpoint, {
            method: this.method$,
            headers: this.headers$,
            body: payload
        }).
            catch((errmsg) => {
            if (raw)
                body = errmsg;
            else
                body =
                    {
                        success: false,
                        message: errmsg
                    };
            this.success$ = false;
        });
        if (this.success$) {
            if (raw)
                body = await http.text();
            else
                body = await http.json();
        }
        return (body);
    }
}
