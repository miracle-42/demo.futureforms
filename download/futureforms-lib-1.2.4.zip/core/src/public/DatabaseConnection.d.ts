import { ConnectionScope } from "../database/ConnectionScope.js";
export declare class DatabaseConnection {
    private conn$;
    static get TRXTIMEOUT(): number;
    static set TRXTIMEOUT(timeout: number);
    static get CONNTIMEOUT(): number;
    static set CONNTIMEOUT(timeout: number);
    constructor(url?: string | URL);
    get scope(): ConnectionScope;
    set scope(scope: ConnectionScope);
    set preAuthenticated(secret: string);
    connect(username?: string, password?: string): Promise<boolean>;
    disconnect(): Promise<boolean>;
    connected(): boolean;
    commit(): Promise<boolean>;
    rollback(): Promise<boolean>;
    sleep(ms: number): Promise<void>;
}
