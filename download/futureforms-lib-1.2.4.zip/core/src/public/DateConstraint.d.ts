export interface DateConstraint {
    message: string;
    dateclazz: string;
    valid(date: Date): boolean;
}
