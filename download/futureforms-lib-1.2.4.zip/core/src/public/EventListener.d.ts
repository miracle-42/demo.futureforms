import { TriggerFunction } from './TriggerFunction.js';
import { EventFilter } from '../control/events/EventFilter.js';
export declare class EventListener {
    addEventListener(method: TriggerFunction, filter?: EventFilter | EventFilter[]): void;
}
