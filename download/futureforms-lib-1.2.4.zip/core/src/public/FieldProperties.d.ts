import { Class } from '../types/Class.js';
import { DataType } from '../view/fields/DataType.js';
import { DataMapper } from '../view/fields/DataMapper.js';
import { BasicProperties } from '../view/fields/BasicProperties.js';
export declare class FieldProperties extends BasicProperties {
    constructor(properties: BasicProperties);
    clone(): FieldProperties;
    setTag(tag: string): FieldProperties;
    setType(_type: DataType): FieldProperties;
    setEnabled(flag: boolean): FieldProperties;
    setReadOnly(flag: boolean): FieldProperties;
    setDerived(_flag: boolean): FieldProperties;
    setRequired(flag: boolean): FieldProperties;
    setHidden(flag: boolean): FieldProperties;
    setStyle(style: string, value: string): FieldProperties;
    setStyles(styles: string): FieldProperties;
    removeStyle(style: string): FieldProperties;
    setClass(clazz: string): FieldProperties;
    setClasses(classes: string | string[]): FieldProperties;
    removeClass(clazz: any): FieldProperties;
    setAttribute(attr: string, value?: any): FieldProperties;
    setAttributes(attrs: Map<string, string>): FieldProperties;
    removeAttribute(attr: string): FieldProperties;
    setValue(value: string): FieldProperties;
    setValidValues(values: string[] | Set<any> | Map<any, any>): FieldProperties;
    setMapper(mapper: Class<DataMapper> | DataMapper | string): FieldProperties;
}
