/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
import { Alert } from '../application/Alert.js';
import { BasicProperties } from '../view/fields/BasicProperties.js';
import { FieldFeatureFactory } from '../view/FieldFeatureFactory.js';
export class FieldProperties extends BasicProperties {
    constructor(properties) {
        super();
        if (properties != null)
            FieldFeatureFactory.copyBasic(properties, this);
    }
    clone() {
        return (new FieldProperties(this));
    }
    setTag(tag) {
        this.tag = tag;
        return (this);
    }
    setType(_type) {
        Alert.fatal("Data type cannot be changed", "Properties");
        return (this);
    }
    setEnabled(flag) {
        this.enabled = flag;
        return (this);
    }
    setReadOnly(flag) {
        this.readonly = flag;
        return (this);
    }
    setDerived(_flag) {
        Alert.fatal("Derived cannot be changed", "Properties");
        return (this);
    }
    setRequired(flag) {
        this.required = flag;
        return (this);
    }
    setHidden(flag) {
        this.hidden = flag;
        return (this);
    }
    setStyle(style, value) {
        super.setStyle(style, value);
        return (this);
    }
    setStyles(styles) {
        this.styles = styles;
        return (this);
    }
    removeStyle(style) {
        super.removeStyle(style);
        return (this);
    }
    setClass(clazz) {
        super.setClass(clazz);
        return (this);
    }
    setClasses(classes) {
        super.setClasses(classes);
        return (this);
    }
    removeClass(clazz) {
        super.removeClass(clazz);
        return (this);
    }
    setAttribute(attr, value) {
        super.setAttribute(attr, value);
        return (this);
    }
    setAttributes(attrs) {
        super.setAttributes(attrs);
        return (this);
    }
    removeAttribute(attr) {
        super.removeAttribute(attr);
        return (this);
    }
    setValue(value) {
        this.value = value;
        return (this);
    }
    setValidValues(values) {
        this.validValues = values;
        return (this);
    }
    setMapper(mapper) {
        super.setMapper(mapper);
        return (this);
    }
}
