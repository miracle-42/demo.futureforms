/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
import { Alert } from '../application/Alert.js';
import { Framework } from '../application/Framework.js';
import { EventType } from '../control/events/EventType.js';
import { FormsModule } from '../application/FormsModule.js';
import { FormBacking } from '../application/FormBacking.js';
import { FormEvent, FormEvents } from '../control/events/FormEvents.js';
/*
 * Any change to this, must be carried forward to interal/form.
 * These 2 classes must be identical to avoid the severe javascript brain damage:
 * ReferenceError: Cannot access 'Form' before initialization, when forms calling forms
 */
export class Form {
    moveable = false;
    navigable = false;
    resizable = false;
    initiated = new Date();
    parameters = new Map();
    constructor(page) {
        page = Framework.prepare(page);
        FormBacking.setBacking(this).page = page;
    }
    get name() {
        return (this.constructor.name.toLowerCase());
    }
    get canvas() {
        return (FormBacking.getViewForm(this)?.canvas);
    }
    get blocks() {
        return (Array.from(FormBacking.getBacking(this).blocks.values()));
    }
    hide() {
        this.canvas.remove();
    }
    show() {
        this.canvas.restore();
        this.focus();
    }
    async clear(force) {
        if (force)
            FormBacking.getModelForm(this)?.clear();
        return (FormBacking.getViewForm(this)?.clear(!force));
    }
    focus() {
        FormBacking.getViewForm(this)?.focus();
    }
    getCurrentBlock() {
        return (this.getBlock(FormBacking.getViewForm(this).block.name));
    }
    async reQuery(block) {
        block = block?.toLowerCase();
        let blk = this.getBlock(block);
        if (blk == null) {
            Alert.fatal("Block '" + block + "' does not exist", "Re Query");
            return (false);
        }
        return (blk.reQuery());
    }
    async enterQueryMode(block) {
        block = block?.toLowerCase();
        let blk = this.getBlock(block);
        if (blk == null) {
            Alert.fatal("Block '" + block + "' does not exist", "Execute Query");
            return (false);
        }
        return (blk.enterQueryMode());
    }
    async executeQuery(block) {
        block = block?.toLowerCase();
        let blk = this.getBlock(block);
        if (blk == null) {
            Alert.fatal("Block '" + block + "' does not exist", "Enter Query Mode");
            return (false);
        }
        return (blk.executeQuery());
    }
    showDatePicker(block, field) {
        block = block?.toLowerCase();
        field = field?.toLowerCase();
        FormBacking.getViewForm(this).showDatePicker(block, field);
    }
    showListOfValues(block, field, force) {
        block = block?.toLowerCase();
        field = field?.toLowerCase();
        FormBacking.getViewForm(this).showListOfValues(block, field, force);
    }
    async sendkey(key, block, field, clazz) {
        return (FormBacking.getViewForm(this).sendkey(key, block, field, clazz));
    }
    link(master, detail, orphanQueries) {
        if (orphanQueries == null)
            orphanQueries = true;
        FormBacking.getBacking(this).setLink(master, detail, orphanQueries);
    }
    goBlock(block) {
        this.getBlock(block)?.focus();
    }
    goField(block, field, clazz) {
        this.getBlock(block)?.goField(field, clazz);
    }
    message(msg, title) {
        Alert.message(msg, title);
    }
    warning(msg, title) {
        Alert.warning(msg, title);
    }
    get valid() {
        if (FormBacking.getModelForm(this).eventTransaction.running() > 0)
            return (false);
        return (FormBacking.getViewForm(this).validated());
    }
    async validate() {
        return (FormBacking.getViewForm(this).validate());
    }
    getView() {
        let view = this.canvas?.getView();
        if (view != null)
            return (this.canvas.getView());
        else
            return (FormBacking.getBacking(this).page);
    }
    getViewPort() {
        return (this.canvas.getViewPort());
    }
    setViewPort(view) {
        this.canvas.setViewPort(view);
    }
    getParentViewPort() {
        return (this.canvas.getParentViewPort());
    }
    getBlock(block) {
        return (FormBacking.getBacking(this).blocks.get(block?.toLowerCase()));
    }
    setDataSource(block, source) {
        FormBacking.getModelForm(this).setDataSource(block?.toLowerCase(), source);
    }
    setListOfValues(lov, block, field) {
        if (!Array.isArray(field))
            field = [field];
        for (let i = 0; i < field.length; i++)
            FormBacking.getBacking(this).setListOfValues(block, field[i], lov);
    }
    setDateConstraint(datecstr, block, field) {
        if (!Array.isArray(field))
            field = [field];
        for (let i = 0; i < field.length; i++)
            FormBacking.getBacking(this).setDateConstraint(block, field[i], datecstr);
    }
    getValue(block, field) {
        return (this.getBlock(block)?.getValue(field));
    }
    setValue(block, field, value) {
        this.getBlock(block)?.setValue(field, value);
    }
    async flush() {
        return (FormBacking.getModelForm(this).flush());
    }
    async showform(form, parameters, container) {
        if (!await this.validate())
            return (null);
        let cform = await FormsModule.get().showform(form, parameters, container);
        return (cform);
    }
    async callform(form, parameters, container) {
        this.canvas.block();
        FormBacking.getBacking(this).hasModalChild = true;
        let cform = await FormsModule.get().showform(form, parameters, container);
        if (cform)
            FormBacking.getBacking(cform).parent = this;
        else
            FormBacking.getBacking(this).hasModalChild = false;
        return (cform);
    }
    reIndexFieldOrder() {
        FormBacking.getViewForm(this).rehash();
    }
    startFieldDragging() {
        let label = Framework.getEvent().target;
        FormBacking.getViewForm(this).dragfields(label);
    }
    async setView(page) {
        let canvas = this.canvas;
        let back = FormBacking.getBacking(this);
        if (page == null) {
            page = "";
            if (back.page == null)
                return;
        }
        if (canvas != null) {
            if (!this.validate()) {
                Alert.warning("Form must be validated before layout can be changed", "Validate");
                return;
            }
            if (FormBacking.getBacking(this).hasEventListeners())
                console.warn("Replacing view will remove all event listeners");
            FormBacking.cleanup(this);
        }
        page = Framework.prepare(page);
        Framework.parse(this, page);
        back.page = page;
        if (canvas != null) {
            canvas.replace(page);
            FormBacking.getViewForm(this, true).canvas = canvas;
        }
        await FormBacking.getViewForm(this, true).finalize();
        await FormBacking.getModelForm(this, true).finalize();
    }
    async close(force) {
        let vform = FormBacking.getViewForm(this);
        if (vform == null)
            return (true);
        await FormBacking.getModelForm(this).wait4EventTransaction(EventType.OnCloseForm, null);
        if (!await FormEvents.raise(FormEvent.FormEvent(EventType.OnCloseForm, this)))
            return (false);
        if (!await this.clear(force))
            return (false);
        this.canvas.close();
        let parent = FormBacking.getBacking(this).parent;
        if (parent != null) {
            parent.canvas.unblock();
            parent.focus();
            if (FormBacking.getBacking(parent))
                FormBacking.getBacking(parent).hasModalChild = false;
        }
        FormBacking.removeBacking(this);
        let success = await FormEvents.raise(FormEvent.FormEvent(EventType.PostCloseForm, this));
        return (success);
    }
    removeEventListener(handle) {
        FormBacking.getBacking(this).removeEventListener(handle);
    }
    addEventListener(method, filter) {
        let handle = FormEvents.addListener(this, this, method, filter);
        FormBacking.getBacking(this).listeners.push(handle);
        return (handle);
    }
}
