import { Case } from "./Case.js";
import { BindValue } from "../database/BindValue.js";
import { Filter } from "../model/interfaces/Filter.js";
import { DataSource } from "../model/interfaces/DataSource.js";
export interface LOVFilterPreProcessor {
    (filter?: string): string;
}
export interface ListOfValues {
    rows?: number;
    width?: string;
    title?: string;
    cssclass?: string;
    inQueryMode?: boolean;
    inReadOnlyMode?: boolean;
    datasource: DataSource;
    filter?: Filter | Filter[];
    bindvalue?: BindValue | BindValue[];
    filterCase?: Case;
    filterPrefix?: string;
    filterPostfix?: string;
    filterMinLength?: number;
    filterInitialValueFrom?: string;
    filterPreProcesser?: LOVFilterPreProcessor;
    sourcefields: string | string[];
    targetfields: string | string[];
    displayfields: string | string[];
}
