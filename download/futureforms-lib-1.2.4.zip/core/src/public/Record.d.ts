import { FieldProperties } from "./FieldProperties.js";
import { Record as Internal, RecordState } from "../model/Record.js";
export declare class Record {
    private rec$;
    constructor(rec: Internal);
    get recno(): number;
    get state(): RecordState;
    get inserted(): boolean;
    get updated(): boolean;
    get deleted(): boolean;
    get synchronized(): boolean;
    get response(): any;
    getValue(field: string): any;
    /**
     * Execute datasource default lock method.
     */
    lock(): Promise<boolean>;
    /**
     * Mark the record as locked.
     */
    markAsLocked(flag?: boolean): void;
    /**
     * Make sure the datasource marks this record updated.
     * @param field any non derived field
     */
    setDirty(field?: string): void;
    /**
     * setAndValidate field value as if changed by a user.
     * @param field
     */
    setAndValidate(field: string, value: any): Promise<boolean>;
    /**
     * Set the field value. This operation neither locks the record, nor marks it dirty
     * @param field
     * @param value
     */
    setValue(field: string, value: any): void;
    getStyle(field: string, style: string): string;
    setStyle(field: string, style: string, value: any): void;
    removeStyle(field: string, style: string): void;
    hasClass(field: string, clazz: string): boolean;
    setClass(field: string, clazz: string): void;
    removeClass(field: string, clazz: string): void;
    hasAttribute(field: string, attr: string): boolean;
    getAttribute(field: string, attr: string): string;
    setAttribute(field: string, attr: string, value?: any): void;
    removeAttribute(field: string, attr: string): void;
    getProperties(field?: string, clazz?: string): FieldProperties;
    setProperties(props: FieldProperties, field: string, clazz?: string): void;
    clearProperties(field: string, clazz?: string): void;
    toString(): string;
}
