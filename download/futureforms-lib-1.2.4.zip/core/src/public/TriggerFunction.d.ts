import { FormEvent } from "../control/events/FormEvent.js";
export interface TriggerFunction {
    (event?: FormEvent): Promise<boolean>;
}
