export type Class<T> = {
    new (...args: any[]): T;
};
export declare function isClass(clazz: any): clazz is Class<any>;
