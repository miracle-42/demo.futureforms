export declare enum Tier {
    Backend = 0,
    Frontend = 1
}
export interface DataMapper {
    getValue(tier: Tier): any;
    setValue(tier: Tier, value: any): void;
    getIntermediateValue(tier: Tier): string;
    setIntermediateValue(tier: Tier, value: string): void;
}
