import { Field } from "./Field.js";
import { FieldInstance } from "./FieldInstance.js";
import { BrowserEvent } from "../../control/events/BrowserEvent.js";
interface event {
    field: Field;
    inst: FieldInstance;
    brwevent: BrowserEvent;
}
export declare class EventStack {
    static stack$: event[];
    static running: boolean;
    static stack(field: Field, inst: FieldInstance, brwevent: BrowserEvent): Promise<void>;
    static handle(): Promise<void>;
}
export {};
