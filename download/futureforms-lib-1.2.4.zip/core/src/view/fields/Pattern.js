/*
  MIT License

  Copyright © 2023 Alex Høffner

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
  and associated documentation files (the “Software”), to deal in the Software without
  restriction, including without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/*
 * Pattern consists of fixed text and fields enclosed by {}.
 * Fields consists of a list of single character regular expressions.
 * Each expression can be repeated using a preceding multiplier.
 * For shorthand, a number of predefined classes can be used.
 *
 * Example: Flight ID BA-2272
 *
 *  {[A-Z][A-Z]}-{[0-9][0-9][0-9][0-9]}
 * or
 *  {2[A-Z]}-{4[0-9]}
 * or
 *  {AA}-{####}
 * or
 *  {2A}-{4#}
 *
 * Predefined classes:
 *
 *  *  : any
 *  #  : [0-9]
 *  d  : [0-9.-]
 *  a  : [a-z]
 *  A  : [A-Z]
 *  w  : [a-z_0-9]
 *  W  : [A-Z_0-9]
 *  c  : any lowercase character
 *  C  : any uppercase character
 */
import { Validity } from "./interfaces/Pattern.js";
export class Pattern {
    pos = 0;
    plen = 0;
    fldno = 0;
    value = "";
    fields = [];
    pattern$ = null;
    placeholder$ = null;
    predefined = "*#dcaAw";
    tokens = new Map();
    constructor(pattern) {
        if (pattern != null)
            this.setPattern(pattern);
    }
    size() {
        return (this.plen);
    }
    isNull() {
        for (let i = 0; i < this.fields.length; i++) {
            if (!this.fields[i].isNull())
                return (false);
        }
        return (true);
    }
    getValue() {
        return (this.value);
    }
    getPosition() {
        return (this.pos);
    }
    getPattern() {
        return (this.pattern$);
    }
    getPlaceholder() {
        return (this.placeholder$);
    }
    setPattern(pattern) {
        let pos = 0;
        let placeholder = "";
        for (let i = 0; i < pattern.length; i++) {
            let c = pattern.charAt(i);
            let esc = this.escaped(pattern, i);
            if (esc) {
                let b = i;
                c = pattern.charAt(++i);
            }
            if (c == '{' && !esc) {
                let fr = i + 1;
                while (i < pattern.length && pattern.charAt(++i) != '}')
                    ;
                if (i == pattern.length)
                    throw "Syntax error in path, non matched {}";
                let def = this.parseFieldDefinition(pattern.substring(fr, i));
                this.fields.push(new Field(this, this.fields.length, pos, pos + def.length));
                def.forEach((token) => { this.tokens.set(pos++, token); placeholder += ' '; });
            }
            else {
                placeholder += pattern.charAt(i);
                this.tokens.set(pos++, new Token('f'));
            }
        }
        if (this.fields.length == 0)
            throw "No input fields defined";
        this.value = placeholder;
        this.pattern$ = pattern;
        this.placeholder$ = placeholder;
        this.plen = placeholder.length;
        this.fields.forEach((fld) => { fld.init(); });
    }
    getField(n) {
        if (n < this.fields.length)
            return (this.fields[n]);
        return (null);
    }
    getFields() {
        return (this.fields);
    }
    findField(pos) {
        if (pos == null)
            pos = this.pos;
        for (let i = 0; i < this.fields.length; i++) {
            let field = this.fields[i];
            if (pos >= field.pos$ && pos <= field.last)
                return (field);
        }
        return (null);
    }
    input(pos) {
        if (pos < 0 || pos > this.placeholder$.length - 1)
            return (false);
        let token = this.tokens.get(pos);
        return (token.type != 'f');
    }
    setValue(value) {
        let valid = true;
        this.value = this.placeholder$;
        if (value == null)
            return (true);
        let pos = 0;
        value = value.trim();
        for (let i = 0; i < this.plen && pos < value.length; i++) {
            let c = value.charAt(pos);
            let p = this.placeholder$.charAt(i);
            let token = this.tokens.get(i);
            if (token.type == 'f') {
                if (c == p)
                    pos++;
            }
            else {
                if (c == ' ' || this.setCharacter(i, c))
                    pos++;
                else
                    valid = false;
            }
        }
        this.fields.forEach((fld) => { fld.init(); });
        if (pos != value.length)
            valid = false;
        return (valid);
    }
    setPosition(pos) {
        if (pos < 0 || pos >= this.plen)
            return (false);
        if (this.tokens.get(pos).type != 'f') {
            this.pos = pos;
            this.onfield();
            return (true);
        }
        return (false);
    }
    findPosition(pos) {
        if (pos >= this.placeholder$.length)
            return (this.placeholder$.length - 1);
        if (this.tokens.get(pos).type == 'f') {
            let fr = pos;
            let to = pos;
            let dist1 = 0;
            let dist2 = 0;
            while (fr > 0 && this.tokens.get(fr).type == 'f')
                fr--;
            while (to < this.placeholder$.length - 1 && this.tokens.get(to).type == 'f')
                to++;
            if (fr == 0 && this.tokens.get(fr).type == 'f')
                fr = to;
            if (to == this.placeholder$.length - 1 && this.tokens.get(to).type == 'f')
                to = fr;
            dist1 = pos - fr;
            dist2 = to - pos;
            pos = fr;
            if (dist2 < dist1)
                pos = to;
        }
        return (pos);
    }
    setCharacter(pos, c) {
        if (!this.setPosition(pos))
            return (false);
        let valid = this.validity(pos, c);
        switch (valid) {
            case Validity.na: return (false);
            case Validity.false: return (false);
            case Validity.asupper:
                c = c.toLocaleUpperCase();
                break;
            case Validity.aslower:
                c = c.toLocaleLowerCase();
                break;
        }
        let a = this.value.substring(this.pos + 1);
        let b = this.value.substring(0, this.pos);
        this.value = b + c + a;
        return (true);
    }
    isValid(pos, c) {
        let valid = this.validity(pos, c);
        if (valid == Validity.false || valid == Validity.na)
            return (false);
        return (true);
    }
    validity(pos, c) {
        let lc = c.toLocaleLowerCase();
        let uc = c.toLocaleUpperCase();
        let valid = Validity.false;
        let token = this.tokens.get(pos);
        if (token == null)
            return (Validity.na);
        switch (token.case) {
            case 'u':
                if (token.validate(uc)) {
                    if (c == uc)
                        valid = Validity.true;
                    else
                        valid = Validity.asupper;
                }
                break;
            case 'l':
                if (token.validate(lc)) {
                    if (c == lc)
                        valid = Validity.true;
                    else
                        valid = Validity.asupper;
                }
                break;
            case '?':
                if (lc == uc) {
                    if (token.validate(c))
                        valid = Validity.true;
                }
                else {
                    if (token.validate(c)) {
                        valid = Validity.true;
                    }
                    else if (c != lc && token.validate(lc)) {
                        valid = Validity.aslower;
                    }
                    else if (c != uc && token.validate(uc)) {
                        valid = Validity.asupper;
                    }
                }
                break;
        }
        return (valid);
    }
    delete(fr, to) {
        if (fr == to) {
            fr--;
            if (fr < 0)
                return (this.value);
            if (!this.setPosition(fr))
                return (this.value);
        }
        let p = "";
        let a = this.value.substring(to);
        let b = this.value.substring(0, fr);
        for (let i = fr; i < to; i++)
            p += this.placeholder$.charAt(i);
        this.value = b + p + a;
        this.setPosition(fr);
        if (to - fr > 1) {
            let curr = this.findField(fr);
            if (curr != null)
                this.fldno = curr.fn;
        }
        return (this.value);
    }
    getFieldArea(pos) {
        if (pos < 0)
            pos = 0;
        if (pos >= this.plen)
            pos = this.plen - 1;
        let fr = pos;
        let to = pos;
        let token = this.tokens.get(pos);
        if (token.type == 'f') {
            let dist1 = 0;
            let dist2 = 0;
            while (fr > 0 && this.tokens.get(fr).type == 'f')
                fr--;
            while (to < this.placeholder$.length - 1 && this.tokens.get(to).type == 'f')
                to++;
            if (fr == 0 && this.tokens.get(fr).type == 'f')
                fr = to;
            if (to == this.placeholder$.length - 1 && this.tokens.get(to).type == 'f')
                to = fr;
            dist1 = pos - fr;
            dist2 = to - pos;
            if (dist2 < dist1)
                fr = to;
            to = fr;
        }
        while (fr > 0 && this.tokens.get(fr).type != 'f')
            fr--;
        while (to < this.placeholder$.length - 1 && this.tokens.get(to).type != 'f')
            to++;
        if (this.tokens.get(fr).type == 'f')
            fr++;
        if (this.tokens.get(to).type == 'f')
            to--;
        return ([fr, to]);
    }
    prev(printable, from) {
        if (from != null)
            this.pos = from;
        let pos = this.pos - 1;
        if (!printable && pos >= 0) {
            this.pos = pos;
            this.onfield();
            return (this.pos);
        }
        while (pos >= 0) {
            if (this.input(pos)) {
                this.pos = pos;
                this.onfield();
                break;
            }
            pos--;
        }
        return (this.pos);
    }
    next(printable, from) {
        if (from != null)
            this.pos = from;
        let pos = this.pos + 1;
        if (!printable && pos < this.plen) {
            this.pos = pos;
            this.onfield();
            return (this.pos);
        }
        while (pos < this.plen) {
            if (this.input(pos)) {
                this.pos = pos;
                this.onfield();
                break;
            }
            pos++;
        }
        return (this.pos);
    }
    onfield() {
        let curr = this.findField(this.pos);
        if (curr.fn != this.fldno)
            this.fldno = curr.fn;
    }
    getstring(fr, to) {
        return (this.value.substring(fr, to));
    }
    setstring(pos, value) {
        this.value = this.replace(this.value, pos, value);
    }
    replace(str, pos, val) {
        return (str.substring(0, pos) + val + str.substring(pos + val.length));
    }
    parseFieldDefinition(field) {
        let tokens = [];
        for (let i = 0; i < field.length; i++) {
            let repeat = "1";
            let c = field.charAt(i);
            if (c >= '0' && c <= '9') {
                repeat = "";
                while (c >= '0' && c <= '9' && i < field.length) {
                    repeat += c;
                    c = field.charAt(++i);
                }
                if (i == field.length)
                    throw "Syntax error in expression, '" + this.predefined + "' or '[]' expected";
            }
            if (this.predefined.includes(c)) {
                for (let f = 0; f < +repeat; f++)
                    tokens.push(new Token(c));
            }
            else {
                let expr = "";
                if (c != '[')
                    throw "Syntax error in expression, '" + this.predefined + "' or '[]' expected";
                c = field.charAt(++i);
                let esc = false;
                while ((c != ']' || esc) && i < field.length) {
                    expr += c;
                    c = field.charAt(i + 1);
                    esc = this.escaped(field, i++);
                }
                if (c != ']')
                    throw "Syntax error in path, non matched []";
                for (let f = 0; f < +repeat; f++)
                    tokens.push(new Token('x').setRegx("[" + expr + "]"));
            }
        }
        return (tokens);
    }
    escaped(str, pos) {
        if (pos == str.length + 1)
            return (false);
        let e = str.charAt(pos);
        let c = str.charAt(pos + 1);
        return (e == '\\' && c != '\\');
    }
}
class Field {
    pattern;
    fn = 0;
    pos$ = 0;
    last$ = 0;
    size$ = 0;
    value$ = null;
    constructor(pattern, fn, fr, to) {
        this.pattern = pattern;
        this.fn = fn;
        this.pos$ = fr;
        this.last$ = to - 1;
        this.size$ = to - fr;
    }
    pos() {
        return (this.pos$);
    }
    get last() {
        return (this.last$);
    }
    size() {
        return (this.size$);
    }
    field() {
        return (this.fn);
    }
    isNull() {
        let empty = true;
        let value = this.pattern.getValue();
        let pattern = this.pattern.getPlaceholder();
        for (let i = 0; i < pattern.length; i++) {
            let c = value.charAt(i);
            let p = pattern.charAt(i);
            if (c != p) {
                empty = false;
                break;
            }
        }
        return (empty);
    }
    getValue() {
        return (this.pattern["getstring"](this.pos$, this.last + 1));
    }
    setValue(value) {
        if (value == null)
            value = "";
        while (value.length < this.size$)
            value += "";
        if (value.length > this.size$)
            value = value.substring(0, this.size$);
        this.pattern["setstring"](this.pos$, value);
    }
    init() {
        this.value$ = this.getValue();
    }
}
class Token {
    type$ = 'f';
    case$ = '?';
    expr$ = null;
    regex = null;
    constructor(type) {
        this.setType(type);
    }
    get type() {
        return (this.type$);
    }
    get case() {
        return (this.case$);
    }
    setType(type) {
        this.type$ = type;
        switch (type) {
            case "c":
                this.setCase('l');
                break;
            case "C":
                this.setCase('u');
                break;
            case "#":
                this.setRegx("[0-9]");
                break;
            case "d":
                this.setRegx("[0-9.-]");
                break;
            case "a":
                this.setRegx("[a-z]").setCase('l');
                break;
            case "A":
                this.setRegx("[A-Z]").setCase('u');
                break;
            case "w":
                this.setRegx("[a-zA-Z_0-9]").setCase('l');
                break;
            case "W":
                this.setRegx("[a-zA-Z_0-9]").setCase('u');
                break;
        }
        return (this);
    }
    setCase(type) {
        this.case$ = type;
        return (this);
    }
    setRegx(expr) {
        this.expr$ = expr;
        this.regex = new RegExp(expr);
        return (this);
    }
    validate(c) {
        switch (this.type$.toLowerCase()) {
            case "*": return (true);
            case "f": return (false);
            case "c": return (c.toLocaleLowerCase() != c.toLocaleUpperCase());
        }
        return (this.regex.test(c));
    }
    toString() {
        return (this.type$ + "[" + this.case$ + "]");
    }
}
