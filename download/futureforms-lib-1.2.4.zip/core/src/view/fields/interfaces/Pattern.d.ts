export declare enum Validity {
    na = 0,
    true = 1,
    false = 2,
    asupper = 3,
    aslower = 4
}
export interface Pattern {
    size(): number;
    isNull(): boolean;
    getPattern(): string;
    setPattern(pattern: string): void;
    getValue(): string;
    setValue(value: any): boolean;
    isValid(pos: number, c: string): boolean;
    validity(pos: number, c: string): Validity;
    prev(printable: boolean, from?: number): number;
    next(printable: boolean, from?: number): number;
    getPosition(): number;
    getFields(): Section[];
    getField(n: number): Section;
    input(pos: number): boolean;
    findField(pos?: number): Section;
    findPosition(pos: number): number;
    setPosition(pos: number): boolean;
    getFieldArea(pos: number): number[];
    delete(fr: number, to: number): string;
    setCharacter(pos: number, c: string): boolean;
}
export interface Section {
    pos(): number;
    size(): number;
    field(): number;
    isNull(): boolean;
    getValue(): string;
    setValue(value: string): void;
}
