# Application directory

Github require at least one file in a directory.
Empty directories are ignored.
